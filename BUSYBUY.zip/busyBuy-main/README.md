#1 Firebase Authentication use for sign in sign up

#2 Firebase Database use for Create read update delete

#3 use hook useState() useEffect() useContext()

#4 useEffect hook for component mount 

#5 React Routing for each page home cart myorder

#6 use react Toast show notification product added product delete

#7 page loading show using loader Sppinner react 

#8 use context hook API for props consumer useContext()

#9 additional task product filter and search

