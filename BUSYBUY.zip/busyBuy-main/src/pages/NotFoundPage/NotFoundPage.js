import styles from "./NotFound.module.css";

export default function NotFoundPage() {
  return (
    <div className={styles.notFound}>
      <img src="https://cdn-icons-png.flaticon.com/128/2748/2748558.png" alt="pahe not found"/>
      
    </div>
  );
}
