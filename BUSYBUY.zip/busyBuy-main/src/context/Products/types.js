// All action for reducer usereducer
export const SET_PRODUCTS = "SET_PRODUCTS";
export const SET_ERROR = "SET_ERROR";
export const TOGGLE_LOADING = "TOGGLE_LOADING";
export const SET_FILTERED_PRODUCTS = "SET_FILTERED_PRODUCTS";
export const SET_CART_PRODUCTS = "SET_CART_PRODUCTS";
