import { createContext } from "react";
// create context API
const ProductsContext = createContext();

export default ProductsContext;
